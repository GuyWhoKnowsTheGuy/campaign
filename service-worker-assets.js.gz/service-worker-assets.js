self.assetsManifest = {
  "version": "V8Pf7ma7",
  "assets": [
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-W4VM4nkZIreBXR8zwV9XS0GrUm/WEmLOjltNQB5x90E=",
      "url": "Campaign.styles.css"
    },
    {
      "hash": "sha256-KGcaExjPdLVQUK4LLvcVezhWrWHUpbcKNRc2A3KmGPU=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-DBp1u4lL78mRbsCDDmG+YYZvmx66gsi7iiJyNlaAVg0=",
      "url": "_framework/Campaign.wxbmo6ddve.wasm"
    },
    {
      "hash": "sha256-Mv6pcRYyoVa13huxfh2b+T2rzvnnrammKvIroc3ZoaM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ah291z8gpv.wasm"
    },
    {
      "hash": "sha256-6ddqnnMMDWpbA2mlFstbX/o5sj7qgUVd5t6EiLfEbMY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.t3m4f0aulk.wasm"
    },
    {
      "hash": "sha256-t6rx/c5JU4RRwifSszd0Xo3vHtZVCRyVZ7wDVSenyfA=",
      "url": "_framework/Microsoft.AspNetCore.Components.fymag2g37i.wasm"
    },
    {
      "hash": "sha256-3u6fVOwmdwoWQ6/9H0X5hvRs5otVuH8/4lj1PBjHBs4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.6ythxrbuxt.wasm"
    },
    {
      "hash": "sha256-fuKpDFdnuA10QXoAvDUZklISrEUAEH9od88sNC7TgLs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.mqgfwo2xzl.wasm"
    },
    {
      "hash": "sha256-R8Rvf+ufvlMX05PSWGUXwGm3hty6uCI9EtqBH2FpDIQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.vejc7kiu4g.wasm"
    },
    {
      "hash": "sha256-+8GdfYwxibM+Tvy+lXvsyXm6YW3CihUN4umxhg0g0UQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.r8o1xobbxj.wasm"
    },
    {
      "hash": "sha256-m9k4pt1S3OsB7nhPn3Spu1JjG5ixGwaWDws5UBzaZjs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ajkzukr0v.wasm"
    },
    {
      "hash": "sha256-0S8+xplhSQmarJJdn4vmu4EsexndHPXAV+EW1kLsQ/A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.vw5lz7suyp.wasm"
    },
    {
      "hash": "sha256-k90CGctxFalYsomiMN8WMOOGlj2axfoTwLimEx6I3Z8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zcsoog2fso.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-bktn6A+e47C4G7m0lx6F0mvmjdX0AJ4gnLmhBJSXjng=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ehm7fihhtt.wasm"
    },
    {
      "hash": "sha256-Nw6fMz9mMm8SS3pPrUsobEC9zzLKC6AKDJhHRldk9VA=",
      "url": "_framework/Microsoft.Extensions.Logging.zh7psstrkj.wasm"
    },
    {
      "hash": "sha256-AmK5n6+U3/TZLOrVpiIo8BOymvR7teo9Z2xKXf82gDI=",
      "url": "_framework/Microsoft.Extensions.Options.q5fxbq8vi3.wasm"
    },
    {
      "hash": "sha256-GDFxnS1juAZhiczI9EwSabygk4C9W720+OLYMi9s7V4=",
      "url": "_framework/Microsoft.Extensions.Primitives.cfrt9anqu8.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-0fcrZvooTfVqJLa+J7kOHXH4P9wP4/FapnIfV5ehd3Q=",
      "url": "_framework/Microsoft.JSInterop.hc5bsvhmbu.wasm"
    },
    {
      "hash": "sha256-PYazaJaSiICSQHEL7iSXD7mQyEm96xkOOaEh2xyLK9s=",
      "url": "_framework/MudBlazor.bmakzl59mn.wasm"
    },
    {
      "hash": "sha256-RBzG9qYc803aFPcilb57plWWaoD45kCfwn37T8PfCSY=",
      "url": "_framework/Serilog.4yb545qr6j.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-QfW3ChurKyL0CXsEExQ1KffRLrf6HuZ5fs4aVfEHaEg=",
      "url": "_framework/System.Collections.Concurrent.znqzposn18.wasm"
    },
    {
      "hash": "sha256-Un/WhbW67agbAfMZGuvdae9NbJSQanyVCieUzZ/ltTY=",
      "url": "_framework/System.Collections.Immutable.qadc1o32zu.wasm"
    },
    {
      "hash": "sha256-ybw1NKbJxAhZzQKe1jBvxZFjXdyBU6vzM268PlEy6ec=",
      "url": "_framework/System.Collections.NonGeneric.55xkw62b0i.wasm"
    },
    {
      "hash": "sha256-Xcd72r/Z6Y68wlDzUcmO6JNpwgJLKsipcUq0+JP9gWo=",
      "url": "_framework/System.Collections.Specialized.nrw3kjn5pv.wasm"
    },
    {
      "hash": "sha256-1tZpIpE86f65yfFnitIJgjpjHu4PukMAZjkMQjsEPxU=",
      "url": "_framework/System.Collections.iu6qgl0klq.wasm"
    },
    {
      "hash": "sha256-LsmJfEfWkhWucGUW61mmewbXdwfgFO53s1kC9dFTOpw=",
      "url": "_framework/System.ComponentModel.Primitives.mng6d4qtpr.wasm"
    },
    {
      "hash": "sha256-ed4wD0MXh8AeMdsjGy7co7umhpFMDKgdikW6CUkFQlI=",
      "url": "_framework/System.ComponentModel.TypeConverter.dvhk35bas4.wasm"
    },
    {
      "hash": "sha256-/vBQJPKxuZj5hnuVviYGodmh1YjfAeyMqKIaaCNjsuQ=",
      "url": "_framework/System.ComponentModel.i0fo9h67cq.wasm"
    },
    {
      "hash": "sha256-R6w1t5jygcXd9YFMCxMuFbL6L+JTrkRG6igyUyRcG+U=",
      "url": "_framework/System.Console.xuazeh4ds1.wasm"
    },
    {
      "hash": "sha256-+rs7BG+9hc4/PzYt0Pls874Jll0wcRgbwwxggk7ECyc=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.qokpvutg3t.wasm"
    },
    {
      "hash": "sha256-vB/mHpU8YWqbonbePTX22jmIRwgl+Gn2euzReK4v7es=",
      "url": "_framework/System.IO.Pipelines.8brogkqzjr.wasm"
    },
    {
      "hash": "sha256-4qD2ZSnzwcKjXprr/lO1x1KeXyqVdnkl5b9bowyfVgk=",
      "url": "_framework/System.Linq.6mk7nlx4lu.wasm"
    },
    {
      "hash": "sha256-KpNTRFCWHBAs1EmY/MZ8l9n9UNVHNa69rzgPPYNGHdM=",
      "url": "_framework/System.Memory.y2swphq4mo.wasm"
    },
    {
      "hash": "sha256-SN3xREGLMZ4urYFOX4YGJNvHlvQnd7sswd5KevY3WT4=",
      "url": "_framework/System.Net.Http.o8dhoaknvo.wasm"
    },
    {
      "hash": "sha256-bZIyo1/j633N5pQMd0MwhjszHTrpQognOO74FxR9NLI=",
      "url": "_framework/System.Net.Primitives.baq20ve775.wasm"
    },
    {
      "hash": "sha256-JEtFuU4HZIIu9lQgPf4TOdbPwBsV/MQIALa5c75OL8Q=",
      "url": "_framework/System.ObjectModel.cmkzocrqkq.wasm"
    },
    {
      "hash": "sha256-dFhSAvjmzS/AdLcg8I4WSiEiCyEDh6RM7O+94pWPae8=",
      "url": "_framework/System.Private.CoreLib.0r81t6boas.wasm"
    },
    {
      "hash": "sha256-j6VN83Y06cwtpo0RfO38JickowzZ2G3aSNXCFaqRP8k=",
      "url": "_framework/System.Private.Uri.nq5yw1tf81.wasm"
    },
    {
      "hash": "sha256-iTel8M+hoSI92c0jJFjN3ENcbqXnumik9GyNDAB4CIA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lpvs49i9za.wasm"
    },
    {
      "hash": "sha256-J/d3+vsGVTuVpUyEfBJ4b5uJchpmwJ7XOT9SzCbsG88=",
      "url": "_framework/System.Runtime.hulxcserfc.wasm"
    },
    {
      "hash": "sha256-OMv0m78kVb0fejHBkAFQR8ppLcZiL/cZYoK1uiRS3rY=",
      "url": "_framework/System.Security.Cryptography.8w3aldlzuj.wasm"
    },
    {
      "hash": "sha256-J9Dql/M4bGzvzKFvTEG4VbH03ZLP3CmgnjaNzGb8DIs=",
      "url": "_framework/System.Text.Encodings.Web.1ypetucuor.wasm"
    },
    {
      "hash": "sha256-UErDiseqBAhSSGMLexrT4hwvKHTchUA3zPWx9KUfolU=",
      "url": "_framework/System.Text.Json.kviri4tccz.wasm"
    },
    {
      "hash": "sha256-RBBgfeKnW+669u64orqbqK+GyhKB4SjQGfno2q6bYcs=",
      "url": "_framework/System.Text.RegularExpressions.0f65kz093l.wasm"
    },
    {
      "hash": "sha256-fcZeJpcx95Puk/XzRsdrgEiNvFAMILZMz6hfkexPKp8=",
      "url": "_framework/System.Threading.7jdwdkbyqt.wasm"
    },
    {
      "hash": "sha256-Sd3s9Vn4Uscsky7aa9pkHZrTKzPZT0ckLQ5cMvbAis0=",
      "url": "_framework/System.l5g27qddaj.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-ZiHUJAu2Q9PFxuMLXgwlf6F3Xk3FNQR9P4kVl8e2HC0=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-0Yl9EiFVGdspgCM8yZBNr+XYVmAIu3wvJhd4CNuCZUQ=",
      "url": "_framework/dotnet.native.10leos28m3.js"
    },
    {
      "hash": "sha256-hSxho6aQuDdRxxTqhBDFQZ4KbVbWRKH4xUoyTvbEpxc=",
      "url": "_framework/dotnet.native.5kzau3xyrq.wasm"
    },
    {
      "hash": "sha256-yJvgPPUUvavYVmu9VD/fYtMcoEnLVaB0Cr7JAE29btw=",
      "url": "_framework/dotnet.runtime.o0qy896u8v.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-+A9GJSL1F7E2tMCpF5MhfSLW2Gd35PbafP4B4Z7MEcE=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Kt/UdNkf0gxRCEMJ7QAMGubMf19wrxTTdZMPWnEwEwg=",
      "url": "images/facebook-logo.png"
    },
    {
      "hash": "sha256-b797d9DruzTD0VQcwZfXrg/+yu/FmOG74fNdDZheYN4=",
      "url": "images/instagram-logo.png"
    },
    {
      "hash": "sha256-mfHvDAa4zQ3F8vVY/mzHP9bb3XsuT4TIy+Jeta5L8wA=",
      "url": "images/tiktok-logo.png"
    },
    {
      "hash": "sha256-ORo6hvQOJTtYTe+l8oTHQCohdacF67K0uUYBEvyS3Hc=",
      "url": "images/x-logo-black.png"
    },
    {
      "hash": "sha256-ECexsFF3J625aXFVonB0Q4HDzpsEexyL2Kk4ncfQeoM=",
      "url": "images/youtube-logo.png"
    },
    {
      "hash": "sha256-u2WzXx+vwXWjqMMqKCn5RdhBkAjlwEmPNiZdvdno5nw=",
      "url": "index.html"
    },
    {
      "hash": "sha256-7smneX0tC+xZROtvJLGTzCOxkhHys0DsoKmH62eaEyw=",
      "url": "manifest.webmanifest"
    }
  ]
};
